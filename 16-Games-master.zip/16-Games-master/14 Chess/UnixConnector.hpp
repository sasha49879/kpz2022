#pragma message("FIXME: UnixConnector.hpp isn't implemented")
#pragma message("NOTE: AI (artificial intelegence) isn't available on Unix systems")

void ConnectToEngine(const char* path)
{ 
  
}


std::string getResponseFromEngine(std::string position)
{
   return "error"; 
}


void CloseConnection()
{
    
}

